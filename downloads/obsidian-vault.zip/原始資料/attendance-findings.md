---
title: 沈伯洋委員會出席與發言資料查核
retrieved: 2026-10-20
cutoff: 2026-10-20
status: 已完成教育委員會名冊與影片交叉核對；完整任期逐字稿未分析
---

# 委員會紀錄查核

查核起點為 2024-02-01 到職日，截止 2026-10-20。兩日期相減為 **992 日**；包含起訖日則是 993 個日曆日。正式委員簡介顯示，沈伯洋第 11 屆各會期的常設委員會為外交及國防委員會，教育及文化委員會並非所屬常設委員會。[官方簡介](https://www.ly.gov.tw/Pages/List.aspx?nodeid=46775)

## 已能確認的結果

1. 官方 iVOD 目錄共有 **263 個不同的發言片段 ID**。已保存全部 53 頁 HTML 並逐筆解析，最早影片為 2024-03-04，最新為 2026-10-15。LYAPI 同條件只回 253 筆，與官方差 10 筆，不能把公民 API 視為沒有缺漏。
2. 官方主辦單位是教育及文化委員會的影片確有 **2 段**，分別是 2024-10-16 與 2024-11-07；這個結果只支持「收錄兩段發言」，不能改寫成「只到場兩次」。
3. 單獨教育及文化委員會的官方議事錄，至少 **4 個會議**將他列在「列席委員」。其中 2024 年 3 月的一會是三天一次會，不能據此算成三個到場日；同一會另記有 3 月 18 日書面質詢。
4. 另有 **4 個含教育及文化委員會的聯席會議**，議事錄將他列為出席或列席。這些不併入前項單獨委員會的數量。
5. 「兩次教文質詢全都是中國」不符完整發言內容。2024-10-16 的前段討論大漢技術學院停招、花東在職進修與教育資源，最後才問千人計畫。2024-11-07 討論大學 TronClass 平台個資、資本與研發背景、遠端漏洞風險；教育、數位資安、兩岸可以同時是這段發言的標籤。

名冊能證明的是官方紀錄如何列名，不能證明全程在場、停留多久或每個開會日都有親自到場。書面質詢、口頭質詢、名冊列席與影片片段必須分開呈現。

## 單獨教育及文化委員會：至少四個列席會議

以下八份議事錄均已下載官方 PDF 原件並抽取文字；額外的 3 月與 5 月名冊已渲染首頁、視覺確認「沈伯洋」位於列席委員欄。

| 會議日期 | 會議代碼 | 官方紀錄 | 發言／質詢紀錄 | 官方原件 |
| --- | --- | --- | --- | --- |
| 2024-03-18、20、21 | 委員會-11-1-22-4 | 列席委員 | 3/18 書面質詢；三天一次會，名冊不分日 | [議事錄 PDF](https://ppg.ly.gov.tw/ppg/SittingAttachment/download/2024031495/PPGB60500_2300_20726_1130327_0004.pdf) |
| 2024-05-08 | 委員會-11-1-22-11 | 列席委員 | 未列其口頭或書面質詢，無該場個人影片 | [議事錄 PDF](https://ppg.ly.gov.tw/ppg/SittingAttachment/download/2024050203/PPGB60500_2300_20726_1130513_0003.pdf) |
| 2024-10-16 | 委員會-11-2-22-4 | 列席委員 | 口頭質詢，iVOD 155620，4 分 34 秒 | [議事錄 PDF](https://ppg.ly.gov.tw/ppg/SittingAttachment/download/2024100990/PPGB60500_2300_20726_1131023_0010.pdf) |
| 2024-11-07 | 委員會-11-2-22-7 | 列席委員 | 口頭質詢，iVOD 156610，3 分 19 秒 | [議事錄 PDF](https://ppg.ly.gov.tw/ppg/SittingAttachment/download/2024103023/PPGB60500_2300_20726_1131111_0009.pdf) |

## 另列聯席會議

| 會議日期 | 組合 | 官方紀錄 | 質詢紀錄 | 官方原件 |
| --- | --- | --- | --- | --- |
| 2024-11-28 | 司法及法制、教育及文化 | 列席委員 | 未列其個人質詢 | [議事錄 PDF](https://ppg.ly.gov.tw/ppg/SittingAttachment/download/2024112288/PPGB60500_4300_20769_1140108_0001.pdf) |
| 2025-08-28 | 八個常設委員會聯席 | 出席委員 | 書面質詢 | [議事錄 PDF](https://ppg.ly.gov.tw/ppg/SittingAttachment/download/2025082111/PPGB60500_2100_20988_1140829_0037.pdf) |
| 2025-10-08、09 | 財政、內政、外交國防、經濟、教育文化、社福衛環 | 出席委員 | 10/8 口頭質詢，iVOD 163952；兩天一次會 | [議事錄 PDF](https://ppg.ly.gov.tw/ppg/SittingAttachment/download/2025100165/PPGB60500_2100_20988_1141014_0013.pdf) |
| 2025-11-06 | 司法及法制、教育及文化 | 列席委員 | 未列其個人質詢 | [議事錄 PDF](https://ppg.ly.gov.tw/ppg/SittingAttachment/download/2025103026/PPGB60500_4300_20916_1141117_0003.pdf) |

## 影片主辦單位分布

此表數的是官方目錄的「主辦單位」。聯席會議在官方目錄也只顯示一個主辦單位，不能把主辦單位當成完整會議組合或政策主題。程序委員會的 36 段分布於 26 個不同發言日期，同日可有多段。

| 官方主辦單位 | 片段 |
| --- | ---: |
| 外交及國防委員會 | 122 |
| 院會 | 53 |
| 程序委員會 | 36 |
| 司法及法制委員會 | 18 |
| 內政委員會 | 14 |
| 全院委員會 | 6 |
| 社會福利及衛生環境委員會 | 5 |
| 財政委員會 | 4 |
| 教育及文化委員會 | 2 |
| 經濟委員會 | 2 |
| 交通委員會 | 1 |
| 總計 | 263 |

## 兩段教育影片的發言內容

- [2024-10-16，iVOD 155620](https://ivod.ly.gov.tw/Play/Clip/1M/155620)：先問大漢技術學院停招後，東部技專與進修資源缺口如何補足；再問千人計畫與教師主動申報機制。原始公報的沈委員發言段落，字面子字串「中國」出現 2 次。
- [2024-11-07，iVOD 156610](https://ivod.ly.gov.tw/Play/Clip/1M/156610)：問大學 TronClass 學習平台的學生個資、港資與中國研發背景，以及已通報的遠端漏洞風險，要求教育部與數發部盤點風險和訂定簽約程序。「中國」出現 10 次。

計數只選 LYAPI `data.gazette.blocks` 中以「沈委員伯洋：」起始的整個段落陣列，包含同一人的續段，排除主席、官員、ASR 與題目。因此 **12 次只是這兩段教育影片的樣本字面計數**，不能標示成任期總量，亦不是主題百分比。原文保存於 `attendance-shen-gazette-155620.txt`、`attendance-shen-gazette-156610.txt`；兩場完整官方公報另存 `attendance-official-gazette-2024100990.pdf`、`attendance-official-gazette-2024103023.pdf`。

## 工具與可重現 endpoint

### 官方

- [官方會議 API 技術說明](https://github.com/LegislativeYuanROCTaiwan/Sittings-opendata)：`ID42Action` 是會議與出席，`ID148Action` 是個人影片，`ID223Action` 是委員會登記發言名單；三者不是同一種資料。
- 官方個人影片目錄：`https://ivod.ly.gov.tw/Demand/ListLgltVideo/7049?page=1`，本次 53 頁，各頁 5 筆，末頁 3 筆。
- 官方議事錄附件連結 API：`https://ppg.ly.gov.tw/ppg/api/v1/getProceedingsList?meetingNo=2024050203`，回傳 DOC 與 PDF 附件，應記錄實際 URL，不自行推測檔名。
- 舊 API：`https://data.ly.gov.tw/odw/ID148Action.action?term=11&sessionPeriod=&meetingDateS=113/02/01&meetingDateE=115/10/20&meetingTime=&legislatorName=沈伯洋&fileType=json`。

### LYAPI v2

- `https://ly.govapi.tw/v2/ivods?屆=11&委員名稱=沈伯洋&limit=100&page=1`，本次 3 頁、253 筆。
- `https://ly.govapi.tw/v2/ivods/155620`、`/156610`，可取得官方公報段落與 AI 轉錄；本研究優先用 `gazette.blocks`。
- `https://ly.govapi.tw/v2/committees/22/meets?屆=11&limit=100&page=1`，本次 2 頁、189 筆，含截止日後的 3 筆預告；實際截止內 186 筆。
- `https://ly.govapi.tw/v2/legislators/11/沈伯洋` 可取得正式委員會分工與 related endpoints。
- [LYAPI Swagger](https://v2.ly.govapi.tw/swagger)，規格檔 `https://v2.ly.govapi.tw/v2/swagger.yaml` 已保存。

## 完整度與常見錯誤

- 189 筆教育相關會議包含考察、公聽會及聯席等不同類型。扣除未來預告後有 186 筆，其中 124 筆有結構化議事錄。單獨教文正式會議共 104 筆、101 筆有結構化議事錄。因此「4 會」應稱為已找到的名冊下限，不宜聲稱已證實完整任期只有 4 會。
- 結構化議事錄也可能漏解析。2024 年 3 月 18 日的沈委員書面質詢存在官方議事錄，但 LYAPI `質詢` 欄沒有列出。本研究以官方原件補正。
- `/legislators/11/沈伯洋/meets` 回傳 115 筆，卻只含院會、全院委員會、公聽會，沒有常設委員會。其 filter 指向 `會議資料.出席委員`，不能用 115 當任期總出席場數。
- `/legislators/11/沈伯洋/interpellations` 回 0 筆；這不代表沒有質詢，官方影片與議事錄已有多筆反例。
- 官方舊 `ID148Action` 在本次請求中只給 127 筆，最新到 2025-01-16，雖然 endDate 設至 2026-10-20；因此舊 API 與新 iVOD 目錄也有資料時效差異。
- 不能用曆日 992 當委員會出席率分母；出席率需要所屬委員會實際開會場次與法定委員身分。也不能從立委工作資料推算台北市長政見分布，後者需另外定義候選人政策文本與時間窗。

## 本地資料

- UI 摘要：`research/attendance-summary.json`。
- 官方 263 筆影片目錄：`attendance-official-ivod-directory.json`，來源頁快照 `attendance-official-ivod-page-1.html` 至 `-53.html`。
- 公民 API 片段：`attendance-ivods-page-1.json` 至 `-3.json`；差異 `attendance-missing-from-lyapi.json`。
- 教文會議：`attendance-education-meets-page-1.json`、`-2.json`；逐會查核 `attendance-education-audit.json`。
- 八份官方名冊原件：`attendance-official-minute-*.pdf`，對應文字 `.txt` 與部分首頁 `.png`。
- 重現腳本：`research/attendance-analyze.py`。使用 pypdf 抽字，匹配官方目錄每個 clip ID，依主辦單位分組，並產生摘要；不對未取得的任期逐字稿填值。

連結知識庫：[[教育委員會出席與發言]]、[[統計方法]]、[[沈伯洋]]、[[待查主張]]。
