"""Read-only data audit for Shen Pao-yang committee records.

Inputs are frozen public API / official iVOD HTML snapshots in research/.
Run with the Codex bundled Python. Outputs use the attendance- prefix.
"""
from pathlib import Path
import json
import re
from collections import Counter
from html import unescape
from datetime import date
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parent

def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding="utf-8")

for pdf in sorted(ROOT.glob("attendance-official-minute-*.pdf")):
    reader = PdfReader(pdf)
    text = "\n\n".join(page.extract_text() or "" for page in reader.pages)
    pdf.with_suffix(".txt").write_text(text, encoding="utf-8")
    # The name can be split by spaces in the official PDF text extraction.
    normalized = re.sub(r"\s+", "", text)
    assert "沈伯洋" in normalized, pdf
    print(pdf.name, "pages", len(reader.pages), "has 沈伯洋", True)

for pdf in sorted(ROOT.glob("attendance-official-gazette-*.pdf")):
    text = "\n\n".join(page.extract_text() or "" for page in PdfReader(pdf).pages)
    pdf.with_suffix(".txt").write_text(text, encoding="utf-8")

clips = []
for p in range(1, 4):
    clips += json.loads((ROOT / f"attendance-ivods-page-{p}.json").read_text(encoding="utf-8-sig"))["ivods"]

ids = [c["IVOD_ID"] for c in clips]
assert len(set(ids)) == len(ids)
counts = Counter("、".join(c["會議資料"].get("委員會代碼:str", [])) or c["會議資料"].get("種類", "未分類") for c in clips)
write_json("attendance-lyapi-summary.json", {
    "retrieved_at": "2026-10-20", "cutoff": "2026-10-20",
    "source": "https://ly.govapi.tw/v2/ivods?屆=11&委員名稱=沈伯洋&limit=100",
    "clip_count": len(clips), "unique_ivod_ids": len(set(ids)),
    "earliest": min(c["日期"] for c in clips), "latest": max(c["日期"] for c in clips),
    "committee_combinations": [{"committee": k, "clips": v} for k, v in counts.most_common()],
    "warning": "A clip is a speaking segment, not attendance. Joint meetings remain their own combination; counts are not legislative topic shares. Official iVOD directory contains 263 clips on the retrieval date versus 253 in LYAPI."
})

for ident in (155620, 156610):
    data = json.loads((ROOT / f"attendance-ivod-{ident}.json").read_text(encoding="utf-8-sig"))["data"]
    # gazette.blocks is the official gazette text, while transcript.whisperx is ASR.
    selected = []
    for block in data.get("gazette", {}).get("blocks", []):
        if block and block[0].startswith("沈委員伯洋："):
            selected += block
    joined = "\n\n".join(selected)
    (ROOT / f"attendance-shen-gazette-{ident}.txt").write_text(joined, encoding="utf-8")
    write_json(f"attendance-clip-{ident}-wordcounts.json", {
        "ivod_id": ident, "date": data["日期"], "speaker": "沈委員伯洋",
        "source": data["IVOD_URL"], "text_source": "gazette.blocks",
        "literal_terms": {term: joined.count(term) for term in ["中國", "教育", "統戰", "TronClass"]},
        "warning": "Literal non-overlapping substring counts in only this speaker's selected gazette blocks. Not all speeches, not a topic percentage, and not a claim assessment."
    })

official = []
for path in sorted(ROOT.glob("attendance-official-ivod-page-*.html"), key=lambda p: int(p.stem.split("-")[-1])):
    html = path.read_text(encoding="utf-8-sig")
    # Match entry boundary by repeated Play/Clip/1M ids, then use local li wrapper.
    for item in re.findall(r"<li\b[^>]*>.*?</li>", html, re.S):
        match = re.search(r"/Play/Clip/1M/(\d+)", item)
        if not match:
            continue
        text = unescape(re.sub(r"<[^>]+>", " ", item))
        text = re.sub(r"\s+", " ", text).strip()
        committee = re.search(r"<h3[^>]*>.*?主辦單位[：:]\s*([^<]+)", unescape(item), re.S)
        when = re.search(r"會議時間：\s*(\d{4}-\d{2}-\d{2})", text)
        duration = re.search(r"影片長度：\s*(\d{2}:\d{2}:\d{2})", text)
        official.append({"ivod_id": int(match[1]), "source_page": path.name, "text": text,
                         "committee": committee[1].strip() if committee else None,
                         "date": when[1] if when else None,
                         "duration": duration[1] if duration else None,
                         "url": "https://ivod.ly.gov.tw/Play/Clip/1M/" + match[1]})
if official:
    write_json("attendance-official-ivod-directory.json", official)
    missing = [entry for entry in official if entry["ivod_id"] not in ids]
    write_json("attendance-missing-from-lyapi.json", missing)
    print("Official directory parsed", len(official), "unique", len(set(e["ivod_id"] for e in official)), "missing from LYAPI", len(missing))
    print("Missing records", [(x["ivod_id"], x["committee"]) for x in missing])

    if len(official) == 263:
        audits = json.loads((ROOT / "attendance-education-audit.json").read_text(encoding="utf-8-sig"))
        single_ids = {"委員會-11-1-22-4": "2024031495", "委員會-11-1-22-11": "2024050203",
                      "委員會-11-2-22-4": "2024100990", "委員會-11-2-22-7": "2024103023"}
        joint_ids = {"聯席會議-11-2-36,22-2": "2024112288", "聯席會議-11-3-20,15,35,19,22,23,36,26-1": "2025082111",
                     "聯席會議-11-4-20,15,35,19,22,26-1": "2025100165", "聯席會議-11-4-36,22-2": "2025103026"}
        singles, joints = [], []
        for row in audits:
            official_id = single_ids.get(row["id"]) or joint_ids.get(row["id"])
            if not official_id:
                continue
            attachment = json.loads((ROOT / f"attendance-official-proceedings-{official_id}.json").read_text(encoding="utf-8-sig"))
            pdf_url = attachment["pdf"].split(";")[0]
            clip_ids = [c["IVOD_ID"] for c in clips if c["會議資料"].get("會議代碼") == row["id"]]
            evidence = "官方議事錄列為" + ("出席委員" if row["attended"] else "列席委員")
            written = row["written"] or row["id"] == "委員會-11-1-22-4"
            if written:
                evidence += "；另有書面質詢紀錄"
            if row["oral"]:
                evidence += "；另有口頭質詢紀錄"
            item = {"dates": row["dates"], "meetingId": row["id"], "title": row["title"],
                    "role": "出席委員" if row["attended"] else "列席委員", "evidence": evidence,
                    "url": pdf_url, "meetingUrl": row["url"], "localPdf": f"research/attendance-official-minute-{official_id}.pdf",
                    "ivodId": clip_ids[0] if clip_ids else None, "ivodIds": clip_ids,
                    "oralQuestion": row["oral"], "writtenQuestion": written,
                    "note": "三天一次會，名冊不分日；不能推算三個到場日。3月18日有書面質詢，LYAPI質詢欄漏解析。" if row["id"] == "委員會-11-1-22-4" else
                            ("兩天一次會，不能推算兩個到場日。" if len(row["dates"]) > 1 else "名冊不表示全程在場。")}
            (singles if row["id"] in single_ids else joints).append(item)
        singles.sort(key=lambda x: x["dates"][0])
        joints.sort(key=lambda x: x["dates"][0])
        committee_counts = Counter(x["committee"] for x in official)
        procedure = [x for x in official if x["committee"] == "程序委員會"]
        source_list = [
            {"title": "立法院官方 iVOD：沈伯洋委員影片目錄", "url": "https://ivod.ly.gov.tw/Demand/ListLgltVideo/7049"},
            {"title": "立法院官方：沈伯洋委員簡介與所屬委員會", "url": "https://www.ly.gov.tw/Pages/List.aspx?nodeid=46775"},
            {"title": "LYAPI v2：沈伯洋 iVOD 片段", "url": "https://ly.govapi.tw/v2/ivods?屆=11&委員名稱=沈伯洋&limit=100"},
            {"title": "LYAPI v2：第11屆教育及文化相關會議", "url": "https://ly.govapi.tw/v2/committees/22/meets?屆=11&limit=100"},
            {"title": "立法院官方 API 技術文件", "url": "https://github.com/LegislativeYuanROCTaiwan/Sittings-opendata"}
        ] + [{"title": x["title"] + "議事錄", "url": x["url"]} for x in singles + joints]
        notes = [
            "統計擷取日與截止日為2026-10-20；影片日期範圍2024-03-04至2026-10-15。以2024-02-01就職為起點，截至2026-10-20經過992日，含起訖日為993個日曆日。",
            "影片263筆是發言片段數，不是出席次數，也不全部是質詢；同日可有多段，程序發言與法案發言均可能收錄。",
            "官方目錄53頁共263個不重複iVOD ID；LYAPI同條件253筆，漏收10筆。官方目錄沒有顯示更多的單獨教文片段，仍為2段。",
            "官方主辦單位欄只有一個名稱；聯席會議會歸在主辦委員會。主辦單位分布不等於政策主題分布，不能據此計算市長政見比例。",
            "單獨教育及文化委員會至少4個會議的議事錄將他列為列席委員，另有4個聯席會議；兩類分開計算。名冊、書面質詢與發言片段不能推定全程在場或實際到場日數。",
            "教育相關會議API共189筆，扣除截止日後預告3筆為186筆；124筆有結構化議事錄。單獨教文104筆、101筆有議事錄，因此列席4會只能稱目前查得下限。",
            "官方委員簡介顯示常設委員會為外交及國防，教育及文化並非所屬委員會；教文發言少不能單獨當作缺席率。",
            "2024-10-16教文質詢先討論大漢技術學院停招、花東進修與教育資源，最後才問千人計畫；不能改述成全程只談中國。",
            "2024-11-07談大學TronClass平台個資、資本與研發背景、遠端漏洞風險，適合多標籤歸類為教育、數位資安、兩岸，而非互斥分類。",
            "兩段公報中只選沈伯洋發言，字面子字串『中國』分別2次、10次，合計12次；這是兩段樣本計數，不是任期總量或政策比例。",
            "LYAPI /legislators/11/沈伯洋/interpellations 回傳0筆，但官方議事錄與影片有質詢紀錄；此資料表不涵蓋全部口頭／書面質詢。",
            "官方舊ID148 API本次回127筆、最晚只到2025-01-16；其時間參數不保證資料更新至截止日，不應用它取代現行官方iVOD目錄。"
        ]
        write_json("attendance-summary.json", {
            "retrievedAt": "2026-10-20", "cutoffDate": "2026-10-20", "termStart": "2024-02-01",
            "elapsedDays": (date(2026,10,20)-date(2024,2,1)).days,
            "officialIvodCount": len(official), "lyapiIvodCount": len(clips), "missingIvodCount": len(missing),
            "educationIvodCount": 2, "educationListedMeetingsAtLeast": len(singles),
            "educationMeetings": singles, "jointEducationMeetings": joints,
            "ivodByCommittee": [{"name": k, "count": v} for k,v in committee_counts.most_common()],
            "procedureIvodCount": len(procedure), "procedureSpeakingDates": len(set(x["date"] for x in procedure)),
            "formalPermanentCommittee": "外交及國防委員會", "formalCommitteeSource": "https://www.ly.gov.tw/Pages/List.aspx?nodeid=46775",
            "educationSpeechTopics": [
                {"date": "2024-10-16", "ivodId": 155620, "summary": "大漢技術學院停招、花東在職進修與教育資源；千人計畫與教師申報機制", "tags": ["教育資源", "高等教育", "城鄉差距", "兩岸與國安"], "literalChinaCount": 2},
                {"date": "2024-11-07", "ivodId": 156610, "summary": "大學TronClass平台之學生個資、資本／研發背景與漏洞風險", "tags": ["高等教育", "個資", "數位資安", "兩岸與國安"], "literalChinaCount": 10}
            ], "notes": notes, "sources": source_list
        })
