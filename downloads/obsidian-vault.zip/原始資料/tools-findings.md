---
title: 台灣國會 MCP 與 API 工具調查
date: 2026-10-20
status: verified
tags: [國會, API, MCP, 可重現研究]
---

# 台灣國會 MCP 與 API 工具調查

查核日：2026-10-20。下列工具可協助蒐集證據；必須區分「官方資料」、「民間彙整」與「AI 整理」。本次沒有安裝套件，也沒有改動使用者全域 MCP 設定。

## 工具比較

| 工具 | 類型與認證 | 最適合用途 | 來源、更新及限制 |
|---|---|---|---|
| [立法院法律提案 API](https://www.ly.gov.tw/Pages/List.aspx?nodeid=153) | 官方 REST，公開 URL，無金鑰參數 | 核對法律提案人、連署人及日期 | 包含日期、屆、會期、會次、案名、提案與連署名單；沒有議案 ID。日期使用民國年月日。官方文件未承諾即時性或速率 SLA。 |
| [立法院委員發言 API](https://www.ly.gov.tw/Pages/List.aspx?nodeid=154) | 官方 REST，公開 URL | 核對會議、主辦單位及發言名單 | 發言名單不是實際出席的完整替代指標，也不是本人逐字稿。 |
| [立法院開放資料平台](https://data.ly.gov.tw/developer.action) | 官方分資料集 API／下載，無文件所載金鑰 | 公報、委員會紀錄、提案、影片等原始資料 | JSON/XML 每頁 1,000 筆；需逐資料集核對欄位、更新日期與適用屆期。 |
| [LYAPI v2](https://ly.govapi.tw/v2) | OpenFun 民間 REST 彙整，實測公開查詢不需金鑰 | 大批議案、共同提案、連署、委員會、議案流程、IVOD | 彙整官方網站，轉換文件為機器可讀內容。基礎程式 BSD 3-Clause，資料標示 CC BY 4.0。不能稱作「立法院官方 API」。有抓取落差，本次遇過 HTTP 429。 |
| [narumiruna/ly-mcp](https://github.com/narumiruna/ly-mcp) | 本機 stdio MCP／CLI；上游 LYAPI | 讓 agent 查議案、立委、會議、法律、表決及公報 | GitHub 目前標示 10 類、42 工具；使用者提供的 [MCP Servers 目錄](https://mcpservers.org/zh-TW/servers/narumiruna/ly-mcp) 仍為 9 類、39 工具，目錄已落後。無獨立資料庫，繼承 LYAPI 的收錄與更新限制。套件 MIT；開發環境 Python 3.12+。 |
| [Twinkle Hub 開放國會](https://hub.twinkleai.tw/zh-TW/changelog/2026-10-07-open-parliament) | 遠端 HTTP MCP，須登入取得 API key | 公報全文查詢、接續讀完整案件、問政摘要與比較、表決 | 2026-10-07 推出；免費方案可用。聲稱公報最早到 2012-11，但早年仍補齊，每次回傳實際 coverage。需要 key，本次僅核對公開文件，沒有實測授權工具。 |
| [Acta](https://acta.tw/api) | 公開 REST 與遠端 MCP，不需帳號或 key | 找原句、引言比對、議題脈絡 | 發言來自公報，主張是 AI 摘要，附原句與審核。**目前只收特定議題，不能視作任期全量發言。** 約每分鐘更新。CC BY 4.0，應標示 Acta.tw、立法院、OpenFun。 |

LYAPI 的營運及資料授權依 [LYAPI 首頁](https://ly.govapi.tw/v2) 與 [開源儲存庫](https://github.com/openfunltd/ly.govapi.tw-v2)。舊版 [v1 文件](https://v1.ly.govapi.tw/) 明示停止維護，新工作請使用 v2。大規模下載可先評估首頁提供的 [OpenFun Hugging Face 資料集](https://huggingface.co/collections/openfun/tw-legislative-yuan-data-67c7e14902935d02b0b97a3f)，另行核對快照日期。

## 官方法律提案交叉核對

已實際下載並保存：

- 原始檔：`research/official-proposals-shen.json`。
- 來源與抓取時間：`research/official-proposals-shen.meta.json`。
- [本次官方查詢](https://www.ly.gov.tw/WebAPI/LegislativeBill.aspx?from=1130201&to=1151020&proposer=%E6%B2%88%E4%BC%AF%E6%B4%8B&mode=json)。

結果是 **99 筆法律提案人紀錄**：`billProposer` 用分號切分並去除空白後，第一位姓名為沈伯洋有 **41 筆**，在其他名次有 **58 筆**。這個 41／58 是「名單首位／非首位」的可重現操作定義，不應把任意多人共同具名都另算成多件法案。原始 API 的 `proposer` 條件涵蓋提案人名單內所有名次；它不是只篩首位提案人。

本查詢不會取得「只連署、未列提案人」的全量案件，不能把 99 當作所有參與法案總數。回應最早日期為 1130301，最新 1150807；查詢到 1151020 並不代表資料已更新到該日。`billStatus` 在本次樣本為空的情況，應改查議案流程原始文書。

## 可重複執行的 REST 查詢

下列使用 `curl.exe`，可用於 Windows PowerShell；換成 `curl` 也適用其他 shell。URL 中的中文交給 `--data-urlencode` 編碼。

### 官方法律提案

```powershell
curl.exe -G 'https://www.ly.gov.tw/WebAPI/LegislativeBill.aspx' --data-urlencode 'from=1130201' --data-urlencode 'to=1151020' --data-urlencode 'proposer=沈伯洋' --data-urlencode 'mode=json'
```

### 官方委員發言名單

```powershell
curl.exe -G 'https://www.ly.gov.tw/WebAPI/LegislativeSpeech.aspx' --data-urlencode 'from=1130201' --data-urlencode 'to=1151020' --data-urlencode 'meeting_unit=教育及文化委員會' --data-urlencode 'mode=json'
```

### LYAPI 立委、提案、連署、會議及質詢

```powershell
curl.exe 'https://ly.govapi.tw/v2/legislators/11/%E6%B2%88%E4%BC%AF%E6%B4%8B'
curl.exe 'https://ly.govapi.tw/v2/legislators/11/%E6%B2%88%E4%BC%AF%E6%B4%8B/propose_bills?limit=1000&page=1'
curl.exe 'https://ly.govapi.tw/v2/legislators/11/%E6%B2%88%E4%BC%AF%E6%B4%8B/cosign_bills?limit=1000&page=1'
curl.exe 'https://ly.govapi.tw/v2/legislators/11/%E6%B2%88%E4%BC%AF%E6%B4%8B/meets?limit=1000&page=1'
curl.exe 'https://ly.govapi.tw/v2/legislators/11/%E6%B2%88%E4%BC%AF%E6%B4%8B/interpellations?limit=1000&page=1'
```

**關鍵：多欄位選擇必須重複同名參數，不能用逗號，也不能用 `output_fields[]`。** 已由 [SearchAction.php 實作](https://github.com/openfunltd/ly.govapi.tw-v2/blob/main/libraries/LYAPI/SearchAction.php) 核對：程式逐一收集名稱完全相同的 `output_fields` 值。逗號字串會被當成一個不存在的欄位；`[]` 會被忽略而回到預設欄位。

```powershell
curl.exe -G 'https://ly.govapi.tw/v2/legislators/11/%E6%B2%88%E4%BC%AF%E6%B4%8B/propose_bills' --data-urlencode 'limit=1000' --data-urlencode 'page=1' --data-urlencode 'output_fields=議案編號' --data-urlencode 'output_fields=議案名稱' --data-urlencode 'output_fields=提案日期' --data-urlencode 'output_fields=提案人' --data-urlencode 'output_fields=連署人' --data-urlencode 'output_fields=案由' --data-urlencode 'output_fields=說明' --data-urlencode 'output_fields=對照表' --data-urlencode 'output_fields=議案流程'
```

以回應 `total`、`total_page` 驗證完整分頁；以 `議案編號` 去重。統計時限制 `議案類別=法律案`、第 11 屆、日期不晚於截止日。已排程未來會議應與已發生會議分開。若遇 429，快取並降低頻率，不要平行重送大量相同查詢。

### Acta 原句檢索與收錄範圍

```powershell
curl.exe 'https://api.acta.tw/coverage'
curl.exe 'https://api.acta.tw/actors/leg_1264?limit=100&offset=0'
curl.exe -G 'https://api.acta.tw/search' --data-urlencode 'q=中國' --data-urlencode 'type=evidence' --data-urlencode 'actor=leg_1264' --data-urlencode 'term=11' --data-urlencode 'from=2024-02-01' --data-urlencode 'to=2026-10-20' --data-urlencode 'limit=100' --data-urlencode 'offset=0'
curl.exe -G 'https://api.acta.tw/quotes/match' --data-urlencode 'actor=沈伯洋' --data-urlencode 'quote=請放入至少六字的待核對引言'
```

[Acta OpenAPI](https://api.acta.tw/openapi.json) 的 `/search` 是逐詞精確 AND 檢索，非語意搜尋。查無結果不代表沒有說過。`/quotes/match` 比對文字相似度，也不保證引言上下文或歸屬正確，應接著開 `/evidence/{id}` 檢查完整對話與官方出處。搜尋及引言比對每 IP 每分鐘 30 次，其他讀取 300 次；超量回 429。

2026-10-20 實查 `/coverage` 顯示的議題是核能政策、國會職權修法、人工智慧基本法；沈伯洋 ID 是 `leg_1264`，名錄的 `evidenceCount=28` 只代表本站已收錄範圍，**不能解讀為全部質詢 28 次**。用於真假題時應保留日期、本人說話的段落、完整上下文、官方公報／影片連結。

## MCP 設定範例

以下僅為可供人工檢視的設定範例，沒有執行或安裝。

### ly-mcp：stdio

依 [原始儲存庫 README](https://github.com/narumiruna/ly-mcp)；`uvx` 會取得並執行套件。正式可重現流程應固定經核驗的版本，避免 `latest` 隨時間變動。

```json
{"mcpServers":{"lymcp":{"command":"uvx","args":["lymcp@latest"]}}}
```

### Acta：遠端 HTTP，免驗證

```json
{"mcpServers":{"acta":{"type":"http","url":"https://api.acta.tw/mcp"}}}
```

### Twinkle Hub：遠端 HTTP，Bearer key

依 [Twinkle 接入文件](https://hub.twinkleai.tw/zh-TW/docs?aud=api)。需由使用者自行取得 key；不要把真實 key 放入公開知識庫。

```json
{"mcpServers":{"twinkle-hub":{"type":"http","url":"https://api.twinkleai.tw/mcp/","headers":{"Authorization":"Bearer YOUR_API_KEY"}}}}
```

工具先 `discover_tools` 再執行；可搜尋 `tw_ly_legislator_profile`、`tw_ly_gazette_search`、`tw_ly_gazette_read`。依 [profile schema](https://hub.twinkleai.tw/zh-TW/tools/ly_legislator_profile)，預設只回摘要及最新三筆；單一 `sections` 配合 `cursor` 逐頁才是完整列表。`coverage` 為零筆的解釋依據，質詢區塊不套用日期篩選。不要直接拿摘要前三筆當任期比例。

## 研究用途判準

- 法案件數：以議案 ID 為單位，首位提案、其他提案、連署各自計數，再作聯集去重；公開角色定義。
- 教育委員會：區分所屬、出席、列席、實際發言、書面質詢；名單及影片缺席不自動等於未到場。
- 程序委員會：區分送案、排案、暫緩、退回、改列、付委及併案；流程出現一次不代表實質審查一次。
- 關鍵字：先定義語料及說話者，只計本人發言；共同提案全文與官員答覆不能冒充本人說過。應同時報詞次、命中文件數、總字數及占比。
- 主題：教育、資訊、兒少、國安可同案多標籤，分類規則及人工核對結果應公開；不能用「中國」兩字代替整個案子的主題。
- 選舉政策：先保存一份有日期、出處及涵蓋範圍的政策語料，再和立院語料分別分析。兩者沒有共同分母，不能直接相減後宣稱虛偽或詐騙。

相關知識庫：[[台灣國會資料工具]]、[[資料口徑與限制]]、[[沈伯洋]]。
