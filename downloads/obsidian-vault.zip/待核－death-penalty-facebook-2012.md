---
title: "待核－death-penalty-facebook-2012"
updated: 2026-10-20
tags: [v4更新, 來源對照, 可覆核研究]
---

# 待核－death-penalty-facebook-2012

## 2012廢死Facebook貼文

狀態：待核實，未納入確證題庫。

目前取得媒體引述，尚未核到本人完整原貼；不收進確證題庫。

**仍缺的證據：**本人 Facebook 原始貼文、完整前後文及精確日期

[目前線索來源](https://www.cna.com.tw/news/aipl/202610070274.aspx)

這是待辦證據線索，不能引用成已證實歸屬、日期或政策立場。

[[待核實言論線索]] · [[原話與政策對照]]
