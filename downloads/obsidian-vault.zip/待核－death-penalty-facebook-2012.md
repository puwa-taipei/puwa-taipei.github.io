---
title: "待核－death-penalty-facebook-2012"
updated: 2026-10-21
tags: [v10更新, 可覆核研究]
---

# 待核－death-penalty-facebook-2012

## 2012廢死Facebook貼文

目前取得媒體引述，尚未核到本人完整原貼；不收進確證題庫。

尚缺：本人 Facebook 原始貼文、完整前後文及精確日期

[線索來源](https://www.cna.com.tw/news/aipl/202610070274.aspx)

[[待核實言論線索]] · [[影片定位與書名核對]]
