---
title: "待核－death-penalty-book-talk-2018"
updated: 2026-10-20
tags: [v4更新, 來源對照, 可覆核研究]
---

# 待核－death-penalty-book-talk-2018

## 2018法扶講座的書名說法

狀態：待核實，未納入確證題庫。

媒體稱他介紹書中作者的論證及反諷，不宜將書介直接當成本人完整死刑主張。2026 報導他再以該書說明目前立場，值得核對完整兩段。

**仍缺的證據：**2018講座精確發言時間碼與原聲核聽、活動日期，以及2026完整受訪影片；已找到法扶原始影片，但未取得可用逐字稿。

[目前線索來源](https://tw.wa01.com/a/chen-bo-yang-2018ceng-shuo-si-xing-ken-ding-lun-shi-zha-qi-shu-ming-rang-da-jia-zhi-dao-si-xing-shi-qi-guai-de-shi-qing.html) · [已找到的原始影片](https://www.youtube.com/watch?v=ZxGS-DdNt-Q)

這是待辦證據線索，不能引用成已證實歸屬、日期或政策立場。

[[待核實言論線索]] · [[原話與政策對照]]
