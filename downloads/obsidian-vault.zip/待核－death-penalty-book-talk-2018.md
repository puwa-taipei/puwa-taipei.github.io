---
title: "待核－death-penalty-book-talk-2018"
updated: 2026-10-21
tags: [v10更新, 可覆核研究]
---

# 待核－death-penalty-book-talk-2018

這是舊版待核入口。v10已新增[[言論－death-book-title-2018]]，層級為媒體直接引述加官方原片metadata，並非逐句核聽。01:12是媒體指定播放起點；完整背景及目前仍未核出的部分見[[影片定位與書名核對]]。
