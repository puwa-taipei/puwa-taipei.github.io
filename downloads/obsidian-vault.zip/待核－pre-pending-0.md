---
title: "待核－pre-pending-0"
updated: 2026-10-20
tags: [v4更新, 來源對照, 可覆核研究]
---

# 待核－pre-pending-0

## 另一段選罷法批評的日期

狀態：待核實，未納入確證題庫。

官方搜尋索引有原句及選罷法前後文，但尚未核定會議日期與影片ID，不可作為日期完整的已驗證題目。

**仍缺的證據：**會議日期與官方影片對應

[目前線索來源](https://ppg.ly.gov.tw/ppg/SittingCappInfo/download/communique1/final/pdf/114/23/LCIDC01_1142301_00005.pdf)

這是待辦證據線索，不能引用成已證實歸屬、日期或政策立場。

[[待核實言論線索]] · [[原話與政策對照]]
