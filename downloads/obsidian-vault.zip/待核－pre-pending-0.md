---
title: "待核－pre-pending-0"
updated: 2026-10-21
tags: [v10更新, 可覆核研究]
---

# 待核－pre-pending-0

## 另一段選罷法批評的日期

官方搜尋索引有原句及選罷法前後文，但尚未核定會議日期與影片ID，不可作為日期完整的已驗證題目。

尚缺：會議日期與官方影片對應

[線索來源](https://ppg.ly.gov.tw/ppg/SittingCappInfo/download/communique1/final/pdf/114/23/LCIDC01_1142301_00005.pdf)

[[待核實言論線索]] · [[影片定位與書名核對]]
