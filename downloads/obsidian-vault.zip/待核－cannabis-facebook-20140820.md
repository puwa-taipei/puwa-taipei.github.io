---
title: "待核－cannabis-facebook-20140820"
updated: 2026-10-20
tags: [v4更新, 來源對照, 可覆核研究]
---

# 待核－cannabis-facebook-20140820

## 2014大麻Facebook另文

狀態：待核實，未納入確證題庫。

目前取得媒體引述，尚未核到本人完整原貼；不收進確證題庫。

**仍缺的證據：**本人 Facebook 原始連結、轉貼文章及自己的完整評論

[目前線索來源](https://news.nextapple.com/politics/20261006/E4ED4696BAD2ADBE0856559F386CB89D)

這是待辦證據線索，不能引用成已證實歸屬、日期或政策立場。

[[待核實言論線索]] · [[原話與政策對照]]
