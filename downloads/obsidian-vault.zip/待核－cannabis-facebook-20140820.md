---
title: "待核－cannabis-facebook-20140820"
updated: 2026-10-21
tags: [v10更新, 可覆核研究]
---

# 待核－cannabis-facebook-20140820

## 2014大麻Facebook另文

目前取得媒體引述，尚未核到本人完整原貼；不收進確證題庫。

尚缺：本人 Facebook 原始連結、轉貼文章及自己的完整評論

[線索來源](https://news.nextapple.com/politics/20261006/E4ED4696BAD2ADBE0856559F386CB89D)

[[待核實言論線索]] · [[影片定位與書名核對]]
