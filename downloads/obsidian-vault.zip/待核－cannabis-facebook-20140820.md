---
title: "待核－cannabis-facebook-20140820"
updated: 2026-10-21
tags: [v12更新, 原始來源核對]
---

# 待核－cannabis-facebook-20140820

此為舊版待核入口。v12已直接取得本人公開原貼，轉見[[言論－cannabis-legalisation-facebook-20140820|本人按語提出以合法化解決大麻背後問題]]與[[v12本人原貼來源狀態]]；不再以政治對手引文代替本人來源。
